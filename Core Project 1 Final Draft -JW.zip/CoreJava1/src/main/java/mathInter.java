//the math interface! starts the methods
public interface mathInter {
	//setting up the math interface with empty methods with parameters
	int getAdd(int x, int y);
	int getSub(int x, int y);
	int  getMult(int x,int y);
	int getDiv (int x, int y);
	

}
