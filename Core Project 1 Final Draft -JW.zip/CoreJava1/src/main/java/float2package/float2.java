package float2package;
//making the second float package

public class float2{
//creating the float variables
//they have to be public
	public float flt1=5;
	public float flt2=6;
	
	public float getFl() {
		return flt1;
	}
	

}
