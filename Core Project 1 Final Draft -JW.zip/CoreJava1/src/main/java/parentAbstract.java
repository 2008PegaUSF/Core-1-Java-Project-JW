
public abstract class parentAbstract {
	//setting up the  abstract methods
	abstract public boolean getCap(String s);
	abstract public String getUpper(String s);
	abstract public int getConvert(String s);

}
