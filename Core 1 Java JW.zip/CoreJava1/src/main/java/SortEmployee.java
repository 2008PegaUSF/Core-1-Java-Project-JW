import java.util.Comparator;

public class SortEmployee implements Comparator<Employee> {

	
	

	public int compare(Employee one, Employee second) {
		return one.name.compareTo(second.name);		
	}
	
	}
	

