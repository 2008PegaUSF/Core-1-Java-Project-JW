import java.util.ArrayList;
import java.util.Collections;

public class employeeRunner{

	public static void main(String[] args) {
		Employee sort=new Employee();
		ArrayList<Employee>eList= new ArrayList<Employee>();
		eList.add(new Employee("Jesse",27,"Programming"));
		eList.add(new Employee("Shea",28,"Bartending"));
		eList.add(new Employee("Tori",26,"Framework"));
		
		System.out.println("unsorted list");
		
		for (int i=0; i<eList.size(); i++) {
			System.out.println(eList.get(i));
		}
		
		Collections.sort(eList, new SortEmployee());
		
		System.out.println("sorted by Name");
		
		for (int i=0; i<eList.size(); i++) {
			System.out.println(eList.get(i));
		}
		
	Collections.sort(eList, new SortAge());
		
		System.out.println("sorted by Age");
		
		for (int i=0; i<eList.size(); i++) {
			System.out.println(eList.get(i));
		}
		
	Collections.sort(eList, new SortDept());
		
		System.out.println("sorted by Department");
		
		for (int i=0; i<eList.size(); i++) {
			System.out.println(eList.get(i));
		}
		
		
		
		

		
	
	}

}
