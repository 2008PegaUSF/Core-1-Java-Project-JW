import java.util.Comparator;
import java.util.ArrayList;
import java.util.Collections;

public class Employee {
	String name;
	int age;
	String department;
	
	public Employee(){
		String name;
		int age;
		String department;
	}
	
	public Employee(String name, int age,String department) {
		this.name=name;
		this.age=age;
		this.department=department;
	}
	
	public String toString() {
		return "Employee - Name:" +name+ ", Age:" +age+ ", Department: "+department;
		
	}

}
