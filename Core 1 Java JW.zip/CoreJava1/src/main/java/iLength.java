
public class iLength {
	public static int value;
	public static void main(String[] args) 	{
		{
		if(args.length > 0) {
			for (int i=0;i<args.length;i++) {
			System.out.println("Number of characters in the string is " +args[0].length());
			value+=args[i].length();}
		}else {System.out.println("There is no command line arguments");
			}
		} 
	}

}
