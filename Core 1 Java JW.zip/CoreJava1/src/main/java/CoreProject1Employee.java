import java.util.Comparator;

public class CoreProject1Employee implements Comparator {
	private String name, department;
	private int age;
	
	public CoreProject1Employee(){
		name = "Jesse";
		department = "Workforce";
		age = 27;			
}
	

	public CoreProject1Employee(String n, String d, int a) {
	this.name= n;
	this.department= d;
	this.age= a;
}
	
	public int compare(Object arg0, Object arg1) {
		CoreProject1Employee firstGuy=(CoreProject1Employee) arg0;
		CoreProject1Employee secondGuy=(CoreProject1Employee) arg1;
		if (firstGuy.getName().equals(secondGuy.getName())){
			if (firstGuy.getDepartment().equals(secondGuy.getDepartment())) {
				
			
				if (firstGuy.getAge() == secondGuy.getAge()){
					return 0;
				} else {if (firstGuy.getAge() < secondGuy.getAge()) {
					return 0;}
					else {
						return 1;
					}
					
				}
			}
			else {
				for(int i=0;i<firstGuy.getDepartment().length(); i++) {
					if (firstGuy.getDepartment().charAt(i)<secondGuy.getDepartment().charAt(i))
						return 0;
					
				}
				return 1;
			}
		}
		else {
		String[] firstName = firstGuy.getName().split(" ");
		String[] secondName = secondGuy.getName().split(" ");
		
		if(firstName[0].equals(secondName[0])) {
			for (int i=0; i<firstName[1].length(); i++) 
			if(firstName[1][]){
				return 0;
			}
		}
		 else {
			 for (int i = 0; i
		 }
		
		
		return 0;}
}

		
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	
}

