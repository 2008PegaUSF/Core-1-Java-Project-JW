import java.util.Comparator;
public class SortAge implements Comparator<Employee>{	
	public int compare(Employee one, Employee second) {
	return one.age-second.age;
}


}
